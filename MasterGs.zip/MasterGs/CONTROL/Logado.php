<?php

require_once '../MODELO/UsuarioLogado.php';
require_once '../MODELO/ModeloProducto.php';

$Userlog = new UsuarioLogado();
session_start();
$user = $Userlog->consultar($_POST["correo"], $_POST["contra"]);
if ($user == null) {
    unset($_SESSION["usuario"]);
    session_destroy();
    require_once '../VISTA/homepage.php';
} else {
    
    $_SESSION["usuario"]= serialize($user);
    if ($user->getTipo() == "Admin") {
        require_once '../VISTA/homepageadmin.php';
    } else {
        require_once '../VISTA/homepage.php';
    }
}
$productolog = new ModeloProducto();
$producto = $productolog->selectAll();
var_dump($producto);
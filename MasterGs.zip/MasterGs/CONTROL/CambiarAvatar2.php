
<?php
require_once '../MODELO/UsuarioLogado.php';
require_once '../CONTROL/Class/User.php';
session_start();
$UsrLog = new UsuarioLogado();
$UsrLog->actualizaAvatar(unserialize($_SESSION["usuario"])->getId(), $_GET["img"]);
$user = unserialize($_SESSION["usuario"]);
$user->setImagen($_GET["img"]);
$_SESSION["usuario"] = serialize($user);

require_once '../CONTROL/Informacion.php';
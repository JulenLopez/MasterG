<?php
class Producto {
    //put your code here
    private $id;
    private $nombre;
    private $descripcion;
    private $foto;
    private $cantidad;
    private $precio;
    
    public function __construct($id, $nombre, $descripcion, $foto, $cantidad,$precio) {
        $this->id = $id;
        $this->nombre = $nombre;
        $this->descripcion = $descripcion;
        $this->foto = $foto;
        $this->cantidad = $cantidad;
        $this->precio = $precio;
    }

    public function getId() {
        return $this->id;
    }

    public function getNombre() {
        return $this->nombre;
    }

    public function getDescripcion() {
        return $this->descripcion;
    }

    public function getFoto() {
        return $this->foto;
    }
    public function getPrecio() {
        return $this->precio;
    }

    public function setId($id): void {
        $this->id = $id;
    }

    public function setNombre($nombre): void {
        $this->nombre = $nombre;
    }

    public function setDescripcion($descripcion): void {
        $this->descripcion = $descripcion;
    }

    public function setFoto($foto): void {
        $this->foto = $foto;
    }

    public function setPrecio($precio): void {
        $this->precio = $precio;
    }
}

<?php

class User {
    
    private $id;
    private $nick;
    private $tipo;
    private $imagen;
    private $correo;
    private $contra;


    public function __construct($id=null, $nick=null,$contra=null, $tipo=null, $imagen=null,$correo=null) {
        $this->id = $id;
        $this->nick = $nick;
        $this->tipo = $tipo;
        $this->imagen = $imagen;
        $this->correo=$correo;
        $this->contra=$contra;
    }

    public function getId() {
        return $this->id;
    }

    public function getNick() {
        return $this->nick;
    }
    public function getContra() {
        return $this->contra;
    }
    public function setContra($contra): void {
        $this->contra = $contra;
    }
    public function getTipo() {
        return $this->tipo;
    }

    public function getImagen() {
        return $this->imagen;
    }

    public function setId($id): void {
        $this->id = $id;
    }

    public function setnick($nick): void {
        $this->nick = $nick;
    }

    public function setTipo($tipo): void {
        $this->tipo = $tipo;
    }

    public function setImagen($imagen): void {
        $this->imagen = $imagen;
    }
    
    public function getCorreo() {
        return $this->correo;
    }

    public function setCorreo($correo): void {
        $this->correo = $correo;
    }


}

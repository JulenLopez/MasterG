<?php

require_once '../MODELO/UsuarioLogado.php';
require_once '../CONTROL/Class/User.php';

$Userlog = new UsuarioLogado();
$user = new User();

if ($_POST["tipo"] == "nuevo") {

    $user->setNick($_POST["nick"]);
    $user->setCorreo($_POST["correo"]);
    $user->setContra($_POST["contra"]);
    $user->setImagen("imgs/avatar/logo.png");

    $user->setTipo("usuario");

    $Userlog->crearUser($_POST["nick"], $_POST["correo"], $_POST["contra"], "imgs/avatar/logo.png", "usuario");

    session_start();
    $_SESSION["usuario"] = serialize($user);

    if ($user->getTipo() == "Admin") {
        require_once '../VISTA/homepageadmin.php';
    } else {
        require_once '../VISTA/homepage.php';
    }
}else if($_POST["tipo"] == "actualizar"){
    session_start();
    $user->setNick($_POST["nick"]);
    $user->setContra($_POST["contra"]);
    $user->setImagen($_POST["imagen"]);

    $Userlog->actualizar($_POST["nick"],unserialize($_SESSION["usuario"])->getCorreo(),$_POST["contra"],$_POST["imagen"]);
    
    $_SESSION["usuario"] = serialize($Userlog->consultar(unserialize($_SESSION["usuario"])->getCorreo(),$_POST["contra"]));
    require_once '../VISTA/userPage.php';
}
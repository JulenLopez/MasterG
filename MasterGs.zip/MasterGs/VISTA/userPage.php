<!doctype html>
<?php
require_once("../CONTROL/Class/User.php");
session_start();
?>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Bootstrap CSS boostrap min y icons-->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
  <link rel="stylesheet" href="../CSS/estilo.css">
  <title>Usuario</title>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<style>
  button {

    -webkit-transition: all 150ms ease-in-out;
    transition: all 150ms ease-in-out;
  }

  button:hover {
    box-shadow: 0 0 10px 0 #3498db inset, 0 0 10px 4px #3498db;

  }

  #imglogo {

    -webkit-animation-name: val1-duration;
    animation-name: val1-duration;
    -webkit-animation-duration: 5s;
    animation-duration: 5s;
  }

  @-webkit-keyframes val1-duration {
    0% {
      transform: rotate(90deg)
    }

    100% {
      transform: rotate(360deg)
    }
  }

  @keyframes val1-duration {
    0% {
      transform: rotate(90deg)
    }

    100% {
      transform: rotate(360deg)
    }
  }
</style>

<body
  style="background-image:url(../imgs/wallpapersden.com_ghostrunner-4k-gaming_2048x1152.jpg); width: 100%; height: 100vh; background-size: cover; background-position: center;">

  <!-- Inicio del menu -->

  <nav class="navbar navbar-expand-md navbar-dark bg-dark fixed-top">
    <div class="container-fluid">
      <!-- icono o nombre -->
      <img id="imglogo" src="../imgs/logo.PNG" class="img-fluid" alt="masterGaming" style="width: 50px;">
      <a class="navbar-brand" href="#">
        <span class="text-warning" tabindex="1">Master Gaming</span>
      </a>

      <!-- boton del menu -->

      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#menu"
        aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <!-- elementos del menu colapsable -->

      <div class="collapse navbar-collapse" id="menu">
        <ul class="navbar-nav me-auto">
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="./homepage.php">Inicio</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Ofertas</a>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown"
              aria-expanded="false">
              Información
            </a>

            <ul class="dropdown-menu bg-info" aria-labelledby="navbarDropdown">
              <li><a class="dropdown-item" href="#">Informacion A</a></li>
              <li><a class="dropdown-item" href="#">Equipos</a>
              <li>
              <li><a class="dropdown-item" href="#">Networking</a></li>
            </ul>
          </li>
        </ul>
      </div>

    </div>
  </nav>
  <section>

    <div class="container-fluid " style="height: 600px;">
      <div class="row">
        <div class="col mt-5"></div>
      </div>
      <div class="row">
        <div class="col mt-5"></div>
      </div>
      <div class="row bg-dark align-items-center justify-content-center m-5">
        <div class="col-4 col-lg-3 m-5">
        <img src="../<?= unserialize($_SESSION["usuario"])->getImagen()?>" width='100' height='100' id="imagen"/><br/>
        <?php
        $thefolder = "../imgs/avatar";
        if ($handler = opendir($thefolder)) {
          while (false !== ($file = readdir($handler))) {
                  if ($file!="." && $file!="..")
                  echo "<img src='../imgs/avatar/". $file . "'  width='100' height='100' class='imagenNueva d-none'/><br>";
          }
          closedir($handler);
      }
        ?>
        </div>
        <div id="usuario" class="col-md-6 text-light" style="display: block;">
          <?php
          echo ("<h2>" . unserialize($_SESSION["usuario"])->getNick() . "</h2>");
          echo ("<h2>" . unserialize($_SESSION["usuario"])->getCorreo() . "</h2>");
          ?>

        </div>
        <div class="col-md-6 text-light" id="ediccion" style="display: none;">
          <form name="regis" action="../CONTROL/Registrar.php" onsubmit="return check()" method="POST">
            <div class="mb-3">
              <label for="reContra" class="col-form-label">Nickname</label>
              <input type="text" class="form-control" id="inputNickRegis" name="nick">
            </div>

            <div class="mb-3">
              <label for="contra" class="col-form-label">Contraseña</label>
              <input type="password" class="form-control" id="inputContraRegis" name="contra">
            </div>

            <div class="mb-3">
              <label for="imagen" class="col-form-label">imagen</label>
              <input type="text" class="form-control" id="imagenNueva" name="imagen">
            </div>
            <input type="hidden" name="tipo" value="actualizar"/>
        </div>
        <div class="row pb-5">
          <div id="Guardar" class="col justify-content-center text-center text-light" style="display: none;">
            <button class="btn btn-outline-success" type="submit" id="btGuardar">Guardar</button>
            <button class="btn btn-outline-danger" type="button" id="btCancelar">Cancelar</button>
          </div>
        </form>
        <div id="Edit" class="col justify-content-center text-center text-light">
            <button class="btn btn-outline-info" type="button" id="btEditar">Editar</button>
          </div>

        </div>
      </div>
    </div>
    </div>


  </section>




  <footer class="bg-dark text-light py-3 mt-5" id="footer">
    <div class="container">
      <div class="row">
        <div class="col-md-4">
          <h4>Información de contacto</h4>
          <ul class="list-unstyled">
            <li><i class="fas fa-map-marker-alt"></i> Dirección: Calle 123, Ciudad</li>
            <li><i class="fas fa-phone"></i> Teléfono: (123) 456-7890</li>
            <li><i class="fas fa-envelope"></i> Email: mastergaming@empresa.com</li>
          </ul>
        </div>
        <div class="col-md-4">
          <h4>Enlaces rápidos</h4>
          <ul class="list-unstyled">
            <li><a href="#">Inicio</a></li>
            <li><a href="#">Productos</a></li>
            <li><a href="#">Nosotros</a></li>
            <li><a href="#">Contacto</a></li>
          </ul>
        </div>
        <div class="col-md-4">
          <h4>Suscríbete a nuestro boletín</h4>
          <form>
            <div class="form-group">
              <label for="email">Correo electrónico:</label>
              <input type="email" class="form-control" id="email" name="email" required>
            </div>
            <button type="submit" class="btn btn-primary">Suscribirse</button>
          </form>
        </div>
      </div>
    </div>
  </footer>







  <!-- Option 1: Bootstrap Bundle with Popper -->
  <script type="" src="../JS/jsuserPage.js"></script>
  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>

</html>
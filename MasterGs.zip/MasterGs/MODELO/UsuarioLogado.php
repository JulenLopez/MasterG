

<?php
require_once '../MODELO/Conexion.php';
require_once '../CONTROL/Class/User.php';


class UsuarioLogado {
    public function __construct() {
    }
    
    public function consultar($correo, $passwd){
    $conn= new Conexion();
    $sql = "SELECT * FROM usuario where correo = ? and contra=?";
    $stmt = $conn->mysql->prepare($sql);
    $stmt->bind_param("ss", $correo,$passwd);
    $stmt->execute();
    $usuario = $stmt->get_result();
    if ($usuario->num_rows == 0) {
        $conn->mysql->close();
        echo("hola");
        return null;
    } else {
        $fila = $usuario->fetch_array(MYSQLI_ASSOC);

        $user = new User($fila["id"],$fila["nick"],$fila["contra"],$fila["tipo"],$fila["imagen"],$fila["correo"]);
        return $user;
    }
    }
    
    public function actualizar($nick,$correo,$contra,$img) {
        $conn= new Conexion();
        $sql = "UPDATE usuario SET nick = ?, contra = ?, imagen = ?  WHERE correo = ?";
        $stmt = $conn->mysql->prepare($sql);
        $stmt->bind_param("ssss", $nick, $contra, $img, $correo);
        $stmt->execute();
        $conn->mysql->close();
    }

    public function crearUser($nick,$correo,$contra,$img,$tipo){
        $conn= new Conexion();
        $sql = "INSERT INTO usuario(nick, contra, imagen, correo, tipo) VALUES (?, ?, ?, ?, ?)";
        $stmt = $conn->mysql->prepare($sql);
        $stmt->bind_param("sssss", $nick, $contra,$img,$correo,$tipo);
        $stmt->execute();
        $conn->mysql->close(); 
    }
}
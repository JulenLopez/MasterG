<?php

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/PHPClass.php to edit this template
 */

/**
 * Description of ModeloProducto
 *
 * @author guerr
 */
class ModeloProducto {
    //put your code here
    private $conectar;
    
    public function __construct() {
        
    }
    
    public function crearProducto($id,$nombre,$descripcion,$foto,$cantidad,$precio){
        $conectar=new Conexion();
        $sql="INSERT INTO producto VALUES(?,?,?,?,?,?)";

            $stmt= $conectar->mysql->prepare($sql);
            $stmt->bind_param("isssii",$id,$nombre,$descripcion,$foto,$cantidad,$precio);
            $stmt->execute();
            $conectar->mysql->close(); 
            
        
    }
    
    public function selectProducto($nombre){
        $conectar=new Conexion();
        $sql="SELECT p.id,p.nombre,p.descripcion,p.foto,p.cantidad,p.precio
            FROM producto p 
            WHERE p.nombre=?;";
        $stmt= $conectar->mysql->prepare($sql);
        $stmt->bind_param("i",$nombre);
        $stmt->execute();
        $new=$stmt->get_result();
        
        if($new->num_rows==1){
            $asociado=$new->fetch_assoc();

            return $asociado;
        }
        
        $conectar->mysql->close(); 
        
    }

    public function selectAll(){
        $conectar=new Conexion();
        $sql="SELECT * FROM producto;";
        $stmt= $conectar->mysql->prepare($sql);
        $stmt->execute();
        $new=$stmt->get_result();
        var_dump($new);
        if($new->num_rows==1){
            $asociado=$new->fetch_assoc();

            return $asociado;
        }
        
        $conectar->mysql->close(); 
        
    }
    
    
    public function delete($id){
        $conectar=new Conexion();
        $sql="DELETE FROM produco p WHERE p.id=?;";
        $stmt= $conectar->mysql->prepare($sql);
        $stmt->bind_param("i",$id);
        $stmt->execute();
        $conectar->mysql->close(); 
    }
    
    
    public function update($id,$nombre,$descripcion,$foto,$cantidad,$precio){
        $conectar=new Conexion();
        
        $sql="UPDATE producto p 
        SET p.nombre =.$nombre.,p.descripcion=.$descripcion.,p.foto=.$foto.,p.cantidad=.$cantidad.,p.precio=.$precio.
        WHERE p.id=?";
        $stmt= $conectar->mysql->prepare($sql);
        $stmt->bind_param("i",$id);
        $stmt->execute();
        $conectar->mysql->close(); 
        
    }


    /*UPDATE Customers
    SET ContactName = 'Alfred Schmidt', City= 'Frankfurt'
    WHERE CustomerID = 1;   ;*/
}

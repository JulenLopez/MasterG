<?php
class Conexion
{
    private $hostname;
    private $usuario;
    private $password;
    private $baseDeDatos;
    public $conexion;



    public function __construct()
    {
        $dat = self::datosConexion();
        foreach ($dat as $key => $value) {
            $this->$key = $value;



        }
        $this->mysql = new mysqli($this->servidor, $this->usuario, $this->password, $this->nombre);
        if ($this->mysql->connect_errno) {

            die("error de conexión: " . $mysql->connect_error);

        }
    }
    private function datosConexion(){
        $direccion = dirname(__FILE__);
        $jsondata = file_get_contents($direccion . "/" . "BaseDatos.json");
        return json_decode($jsondata, true);
    }
}
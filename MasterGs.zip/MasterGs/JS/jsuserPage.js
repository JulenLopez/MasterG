

var btEditar = document.getElementById('btEditar')
var btCancelar = document.getElementById('btCancelar')
var btGuardar = document.getElementById('btGuardar')
var imagenNueva = document.getElementsByClassName('imagenNueva')
var regexImg = /(?=img).*/

btEditar.addEventListener("click", ocultar);
btCancelar.addEventListener("click", mostrar);
btGuardar.addEventListener("click", check);

for(let i = 0; i < imagenNueva.length; i++){
    imagenNueva[i].addEventListener("click", function(){
        getPath(imagenNueva[i])
    });
}
function ocultar() {

    document.getElementById('Edit').style.display = 'none';
    document.getElementById('Guardar').style.display = 'flex';
    document.getElementById('btCancelar').style.display = 'flex';
    document.getElementById('ediccion').style.display = 'flex';
    document.getElementById('usuario').style.display = 'none';
    document.getElementById('imagen').style.display = 'none';

    for(let i = 0; i < imagenNueva.length; i++){
        imagenNueva[i].setAttribute("class","imagenNueva");
    }
  }

  function mostrar() {
    document.getElementById('Edit').style.display = 'flex';
    document.getElementById('Guardar').style.display = 'none';
    document.getElementById('btCancelar').style.display = 'none';
    document.getElementById('ediccion').style.display = 'none';
    document.getElementById('usuario').style.display = 'block';
    document.getElementById('imagen').style.display = 'block';

    for(let i = 0; i < imagenNueva.length; i++){
        imagenNueva[i].setAttribute("class","imagenNueva d-none");
    }
  }
  function check(){
    let inputContraRegis = document.getElementById("inputContraRegis")
    let imagenNueva = document.getElementById("imagenNueva")
    let inputCorreoRegis = document.getElementById("inputCorreoRegis")
    let inputNickRegis = document.getElementById("inputNickRegis")
    if(inputContraRegis.value =="" || imagenNueva.value =="" || inputCorreoRegis.value =="" || inputNickRegis.value ==""){
        if(inputContraRegis.value ==""){
            inputContraRegis.setCustomValidity("Conraseña vacia");
        }
        if(imagenNueva.value ==""){
            imagenNueva.setCustomValidity("No has seleccionado una imagen");
        }
        if(inputCorreoRegis.value ==""){
            inputCorreoRegis.setCustomValidity("Correo vacio");
        }
        if(inputNickRegis.value ==""){
            inputNickRegis.setCustomValidity("Nickname vacio");
        }
        return false;
    }
  }

  function getPath(imagen){
    let rutaImagen = imagen.src.match(regexImg)[0]
    document.getElementById("imagenNueva").value=rutaImagen
  }
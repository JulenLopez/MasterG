const btLogin = document.getElementById("btLogin")
const btRegistrarse = document.getElementById("btRegistrarse")
const btAnadir = document.getElementsByClassName("botonAnadir")
const carrito = document.getElementById("productosCarrito")
btRegistrarse.addEventListener("click",checkRegis)

if(localStorage.getItem("productos")!=null){
    carrito.innerHTML = localStorage.getItem("productos")
}
else
    localStorage.setItem("productos", 0)
//Comprobacion valores

//funcion carrito
for(let i = 0; i < btAnadir.length; i++){
btAnadir[i].addEventListener("click",(evento)=>{
    if (evento.target.tagName === 'BUTTON') {
        localStorage.setItem("productos", parseInt(localStorage.getItem("productos"))+1)
        const button = evento.target;
        const p = button.parentNode;
        carrito.innerHTML = localStorage.getItem("productos")
        let producto = p.parentNode.firstElementChild.value;
        if(localStorage.getItem(producto)!=null){
            let aux = parseInt(localStorage.getItem(producto))
            localStorage.setItem(producto, aux+1)
        }else{
            localStorage.setItem(producto, 1)
        }
    }
})}

function checkRegis(){
    let inputCorreoRegis = document.getElementById("inputCorreoRegis")
    let inputReCorreoRegis = document.getElementById("inputReCorreoRegis")
    let inputContraRegis = document.getElementById("inputContraRegis")
    let inputReContraRegis = document.getElementById("inputReContraRegis")
    let inputNickRegis = document.getElementById("inputNickRegis")

    if(inputCorreoRegis.value =="" || inputReCorreoRegis.value =="" || inputContraRegis.value =="" || inputReContraRegis.value =="" || inputNickRegis.value==""){
        if(inputContraRegis.value ==""){
            inputContraRegis.setCustomValidity("Contraseña vacia");
        }
        if(inputReCorreoRegis.value ==""){
            inputReCorreoRegis.setCustomValidity("Correo vacio");
        }
        if(inputCorreoRegis.value ==""){
            inputCorreoRegis.setCustomValidity("Correo vacio");
        }
        if(inputReContraRegis.value ==""){
            inputReContraRegis.setCustomValidity("Contraseña vacia");
        }
        if(inputNickRegis.value ==""){
            inputNickRegis.setCustomValidity("Nick vacio");
        }
        return false;
    }else if(inputCorreoRegis.value == inputReCorreoRegis.value){
        inputReCorreoRegis.setCustomValidity("Correos no coinciden");
        return false;
    }else if(inputContraRegis.value == inputReContraRegis.value){
        inputReContraRegis.setCustomValidity("Contraseñas no coinciden");
        return false;
    }
  }
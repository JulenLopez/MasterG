document.addEventListener('DOMContentLoaded', () => {
    const ul =document.getElementById("lista")
    var cantidadProductos = [],
        nombreProductos = Object.keys(localStorage);
    for(let i = 0; i < nombreProductos.length; i++){
        cantidadProductos.shift(localStorage.getItem(nombreProductos[i]));
        console.log(nombreProductos[i])
        if(nombreProductos[i]!="productos"){
            ul.appendChild(createLI(nombreProductos[i]),cantidadProductos[i])
        }
    }
})

function createLI(titulo, numero) {
    numero = localStorage.getItem(titulo)
    function createElement(elementName, property, valor) {
      const element = document.createElement(elementName);
      element[property] = valor;
      return element;
    }

    function appendToLI(elementName, property, value) {
      const element = createElement(elementName, property, value);
      if(elementName=="input"){
        element.setAttribute("type","number")
        element.setAttribute("value", value)
      }
      li.appendChild(element);
      return element;
    }
    
    const li = document.createElement('li');
    appendToLI('span', 'textContent', titulo);
    appendToLI('input', 'value', numero);
    appendToLI('button', 'textContent', 'Eliminar');

    return li;
  }
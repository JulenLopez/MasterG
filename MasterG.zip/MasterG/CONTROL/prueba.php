<?php

require_once './ControlModel.php';
$mood=new ControlModel();
print_r($mood->logar("usuario1", "usuario1"));
